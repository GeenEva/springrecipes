package eva.recipes.chapter6security1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter6Security1Application {

	public static void main(String[] args) {
		SpringApplication.run(Chapter6Security1Application.class, args);
	}

}
